﻿using System;
using System.Collections.Generic;


using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;


namespace SeleniumDay1
{
    class Program
    {
        //test program
        static void Main(string[] args)
        {

            // Console.WriteLine("web driver is started...");

            //IWebDriver : is interface
            //ChromeDriver : is inbuilt class

            //   IWebDriver driver = new ChromeDriver();
            // driver.Url = "https://www.google.com/"; //open url 

            //enter data 
            //id, name , class, linktext, xpath , cssSelector 
            //driver.FindElement(By.Name("q")).SendKeys("selenium learning");



            //driver.FindElement(By.Name("q")).Click();


            //call to function 

            //Practice_selenium_day1 o = new Practice_selenium_day1();
            
              //  o.open();



            Console.ReadKey();
            
        }
    }
}
